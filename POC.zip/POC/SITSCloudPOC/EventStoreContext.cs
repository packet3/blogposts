﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SITSCloudPOC
{
    public partial class EventStoreContext : DbContext
    {
        public EventStoreContext()
        {
        }

        public EventStoreContext(DbContextOptions<EventStoreContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Event> Events { get; set; } = null!;
        public virtual DbSet<EventMsg> EventMsgs { get; set; } = null!;
        public virtual DbSet<KeyField> KeyFields { get; set; } = null!;
        public virtual DbSet<NewValue> NewValues { get; set; } = null!;
        public virtual DbSet<PreviousValue> PreviousValues { get; set; } = null!;

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    if (!optionsBuilder.IsConfigured)
        //    {

        //        optionsBuilder.UseSqlServer("Server=DWWEBSTGII04;Database=EventStore;User Id=JoeTest; Password=testingpassword");
        //    }
        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Event>(entity =>
            {
                entity.HasKey(e => e.ChangeGuid);

                entity.ToTable("Event");

                entity.Property(e => e.ChangeGuid)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ChangeDate).HasColumnType("date");

                entity.Property(e => e.ChangeDct)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("ChangeDCT");

                entity.Property(e => e.ChangeEnt)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("ChangeENT");

                entity.Property(e => e.ChangeType)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.TimeStampInserted).HasColumnType("smalldatetime");

                entity.Property(e => e.TimeStampProcessed).HasColumnType("smalldatetime");
            });

            modelBuilder.Entity<EventMsg>(entity =>
            {
                entity.HasKey(e => e.ChangeGuid);

                entity.ToTable("EventMsg");

                entity.Property(e => e.ChangeGuid)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EventMsg1).HasColumnName("EventMsg");

                entity.Property(e => e.TimestampInserted).HasColumnType("smalldatetime");
            });

            modelBuilder.Entity<KeyField>(entity =>
            {
                entity.ToTable("KeyField");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.ChangeGuid)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Value)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.ChangeGu)
                    .WithMany(p => p.KeyFields)
                    .HasForeignKey(d => d.ChangeGuid)
                    .HasConstraintName("FK_KeyField_Event");
            });

            modelBuilder.Entity<NewValue>(entity =>
            {
                entity.ToTable("NewValue");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.ChangeGuid)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Value)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.ChangeGu)
                    .WithMany(p => p.NewValues)
                    .HasForeignKey(d => d.ChangeGuid)
                    .HasConstraintName("FK_NewValue_Event");
            });

            modelBuilder.Entity<PreviousValue>(entity =>
            {
                entity.ToTable("PreviousValue");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.ChangeGuid)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Value)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.ChangeGu)
                    .WithMany(p => p.PreviousValues)
                    .HasForeignKey(d => d.ChangeGuid)
                    .HasConstraintName("FK_PreviousValue_Event");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
