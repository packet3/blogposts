﻿using MediatR;

namespace SITSCloudPOC.Features.Event
{
    public class CreateEventCommand : IRequest<string>
    {
        public string ChangeGuid { get; set; }
        public string ChangeSequence { get; set; }
        public string ChangeDate { get; set; }
        public string ChangeTime { get; set; }
        public string ChangeType { get; set; }
        public string ChangeDCT { get; set; }
        public string ChangeENT { get; set; }
        public List<EntityAPI> EntityAPIs { get; set; }
        public PrimaryKeySITSValues PrimaryKeySITSValues { get; set; }
        public PrimaryKeyValues PrimaryKeyValues { get; set; }
        public PreviousValues PreviousValues { get; set; }
        public NewValues NewValues { get; set; }
    }
  
    public class EntityAPI
    {
        public string APIName { get; set; }
        public string APIEndpoint { get; set; }
    }

    public class PrimaryKeySITSValues
    {
        public string CAP_STUC { get; set; }
        public string CAP_APFS { get; set; }
        public string CAP_SEQN { get; set; }
    }

    public class PrimaryKeyValues
    {
        public string AcademicYearCode { get; set; }
    }

    public class PreviousValues
    {
        public string AcademicYearStartYear { get; set; }
    }

    public class NewValues
    {
        public decimal AcademicYearStartYear { get; set; }
    }

 
}
