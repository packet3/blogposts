﻿namespace SITSCloudPOC.Features.Event
{
    public class CreateEventCommandResponse
    {
    }
}
