﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using SITSCloudPOC.Enums;
using System.Reflection;

namespace SITSCloudPOC.Features.Event
{
    public class CreateEventCommandHandler : IRequestHandler<CreateEventCommand, string>
    {
        private readonly DatahubContext _context;

        public CreateEventCommandHandler(DatahubContext context)
        {
            _context = context;
        }
        public async Task<string> Handle(CreateEventCommand request, CancellationToken cancellationToken)
        {
            switch (request.ChangeENT)
            {
                case nameof(EventEntityCode.AYR):
                         AcademicYear academicYear = new AcademicYear()
                        {
                            AcademicYearCode = request.PrimaryKeyValues.AcademicYearCode,
                            AcademicYearStartYear = request.NewValues.AcademicYearStartYear,
                        };
                        PerformDBWork<AcademicYear>(academicYear, request.ChangeType);
                      
                        return "testing"; // would be the actual response from DB for now just have any string.
                 
                default:
                    return "Invalid Entityt"; //would be more of a failed message
                    break;
            }
          
          
        }

        public void PerformDBWork<T>(T entityObj, string changeType) where T : class
        {
            var entity = _context.Set<T>();
            switch (changeType)
            {
                case "N":
                    
                    entity.Add(entityObj);
                   
                    break;
                case "U":
                    entity.Update(entityObj);

                    break;
            }
            _context.SaveChanges();


        }
    }
}
