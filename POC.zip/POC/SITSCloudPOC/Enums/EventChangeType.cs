﻿namespace SITSCloudPOC.Enums
{
    public enum EventChangeType
    {
        N, //New Record
        U // Update record
    }
}
