﻿namespace SITSCloudPOC.Enums
{
    public enum EventEntityCode
    {
        AYR,
        CAP,
        CBO,
        CCL,
        COD,
        CRS,
        DSB,
        FAC,
        FST,
        INS,
        MOA,
        MST,
        NAT,
        SCC,
        SCE,
        SCJ,
        SSP,
        STA,
        STU,
        TTL,
        VCO,
    }
}
