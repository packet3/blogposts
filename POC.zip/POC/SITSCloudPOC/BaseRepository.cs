﻿using Microsoft.EntityFrameworkCore;
using SITSCloudPOC.Interfaces;


namespace SITSCloudPOC
{
    public class BaseRepository<T> : IAsyncRepository<T> where T : class
    {
        private readonly DatahubContext _context;
        internal DbSet<T> dbSet;
        public BaseRepository(DatahubContext context)
        {
            _context = context;
            dbSet = context.Set<T>();
        }
        //https://stackoverflow.com/questions/30675564/in-entity-framework-how-do-i-add-a-generic-entity-to-its-corresponding-dbset-wi

        public async Task Create(T entity)
        {
            await _context.Set<T>().AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public Task DeleteAsync(T entity)
        {
            throw new NotImplementedException();
        }

        public Task<T> UpdateAsync(T entity)
        {
            throw new NotImplementedException();
        }

      
    }
}
