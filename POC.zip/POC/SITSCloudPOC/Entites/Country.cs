﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Country
    {
        public string Code { get; set; } = null!;
        public string? FullName { get; set; }
        public string? GeographicCode { get; set; }
    }
}
