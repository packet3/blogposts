﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Event
    {
        public Event()
        {
            KeyFields = new HashSet<KeyField>();
            NewValues = new HashSet<NewValue>();
            PreviousValues = new HashSet<PreviousValue>();
        }

        public string ChangeGuid { get; set; } = null!;
        public int ChangeSequence { get; set; }
        public DateTime ChangeDate { get; set; }
        public TimeSpan ChangeTime { get; set; }
        public string ChangeType { get; set; } = null!;
        public string ChangeDct { get; set; } = null!;
        public string ChangeEnt { get; set; } = null!;
        public DateTime TimeStampInserted { get; set; }
        public DateTime? TimeStampProcessed { get; set; }

        public virtual ICollection<KeyField> KeyFields { get; set; }
        public virtual ICollection<NewValue> NewValues { get; set; }
        public virtual ICollection<PreviousValue> PreviousValues { get; set; }
    }
}
