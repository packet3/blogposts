﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class StudentClearanceCheck
    {
        public string? StudentCode { get; set; }
        public string? SequenceNumber { get; set; }
        public string? ClearanceCheckCode { get; set; }
        public string? ClearanceChecked { get; set; }
        public decimal? ApplicationFormSequenceNumber { get; set; }
        public decimal? ApplicationSequenceNumber { get; set; }
    }
}
