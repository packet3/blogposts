﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Student
    {
        public string? StudentCode { get; set; }
        public string? PersonCode { get; set; }
        public string? Ucasid { get; set; }
        public string? StudentStatusCode { get; set; }
        public string? ActivityAnalysis2 { get; set; }
        public string? PublicityFlag { get; set; }
        public string? Overseas { get; set; }
        public string? InstitutionCode { get; set; }
        public string? SponsorCode { get; set; }
        public string? StudentSupportNumber { get; set; }
        public string? Tier4Visa { get; set; }
        public string? Ukvi { get; set; }
    }
}
