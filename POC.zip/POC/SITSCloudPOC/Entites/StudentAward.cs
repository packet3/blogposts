﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class StudentAward
    {
        public string? StudentCourseMembershipId { get; set; }
        public string? AcademicYearCode { get; set; }
        public string? AwardCode { get; set; }
        public DateTime? DateAwardConferred { get; set; }
        public string? AwardStatusCode { get; set; }
        public string? Heddstatus { get; set; }
        public string? HeddprocessedDate { get; set; }
        public string? FullName { get; set; }
    }
}
