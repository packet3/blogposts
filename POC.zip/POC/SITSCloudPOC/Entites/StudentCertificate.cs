﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class StudentCertificate
    {
        public decimal? SequenceNumber { get; set; }
        public string? AwardCode { get; set; }
        public string? ClassificationCode { get; set; }
        public DateTime? AwardDate { get; set; }
        public string? StudentCourseMembershipId { get; set; }
        public string? AwardName { get; set; }
    }
}
