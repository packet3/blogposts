﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Module
    {
        public string ModuleCode { get; set; } = null!;
        public string? ShortName { get; set; }
        public string? Name { get; set; }
        public string? DepartmentCode { get; set; }
        public string? InUse { get; set; }
        public string? ModuleCustomAttribute1 { get; set; }
    }
}
