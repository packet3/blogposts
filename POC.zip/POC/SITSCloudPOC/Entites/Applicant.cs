﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Applicant
    {
        public string ApplicantCode { get; set; } = null!;
        public string? PersonCode { get; set; }
        public string? ApplicationFormSequenceNumber { get; set; }
        public string? ApplicationSequenceNumber { get; set; }
        public string? StudentCourseJoinCode { get; set; }
    }
}
