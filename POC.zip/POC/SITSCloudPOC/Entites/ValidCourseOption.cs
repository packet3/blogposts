﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class ValidCourseOption
    {
        public string CourseCode { get; set; } = null!;
        public decimal? SequenceNumber { get; set; }
        public string? InUse { get; set; }
        public string? InPlaceCourseDescription { get; set; }
    }
}
