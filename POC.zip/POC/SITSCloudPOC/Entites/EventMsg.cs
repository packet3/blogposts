﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class EventMsg
    {
        public string ChangeGuid { get; set; } = null!;
        public string EventMsg1 { get; set; } = null!;
        public DateTime TimestampInserted { get; set; }
        public bool IsProcessed { get; set; }
    }
}
