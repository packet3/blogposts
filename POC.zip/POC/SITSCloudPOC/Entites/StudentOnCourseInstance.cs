﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class StudentOnCourseInstance
    {
        public string? StudentCourseJoinCode { get; set; }
        public string? SequenceNumber { get; set; }
        public string? StudentCode { get; set; }
        public string? AcademicYearCode { get; set; }
        public string? CourseCode { get; set; }
        public string? CourseBlockCode { get; set; }
        public string? CourseBlockOccurrenceCode { get; set; }
        public string? CourseGroupCode { get; set; }
        public string? ModeCode { get; set; }
        public string? EnrolmentStatusCode { get; set; }
        public string? NextCourseCode { get; set; }
        public string? NextCourseBlockCode { get; set; }
        public string? NextCourseOccurrenceCode { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? FeeStatusCode { get; set; }
        public string? ProgresStatus { get; set; }
        public string? RouteCode { get; set; }
        public string? DepartmentCode { get; set; }
        public string? FacultyCode { get; set; }
        public string? NextStatusCode { get; set; }
        public string? NextRouteCode { get; set; }
    }
}
