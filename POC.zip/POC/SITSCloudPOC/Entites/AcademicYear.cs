﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class AcademicYear
    {
        public string AcademicYearCode { get; set; } = null!;
        public decimal? AcademicYearStartYear { get; set; }
    }
}
