﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Faculty
    {
        public string Code { get; set; } = null!;
        public string? ShortlName { get; set; }
        public string? FullName { get; set; }
    }
}
