﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Institute
    {
        public string InstitutionCode { get; set; } = null!;
        public string? TenantName { get; set; }
        public string? InstitutionHesaid { get; set; }
    }
}
