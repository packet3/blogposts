﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Status
    {
        public string Code { get; set; } = null!;
        public string? FullName { get; set; }
    }
}
