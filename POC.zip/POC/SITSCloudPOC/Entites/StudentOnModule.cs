﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class StudentOnModule
    {
        public string? StudentCourseMembershipId { get; set; }
        public string? ModuleCode { get; set; }
        public string? Occurrence { get; set; }
        public string? AcademicYearCode { get; set; }
        public string? PeriodSlotCode { get; set; }
        public string? Keatsaccess { get; set; }
    }
}
