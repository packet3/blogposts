﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class CourseApplication
    {
        public string? ApplicantCode { get; set; }
        public string? ApplicationFormSequenceNumber { get; set; }
        public string? ApplicationSequenceNumber { get; set; }
        public string? StatusCode { get; set; }
        public string? AcademicYearCode { get; set; }
        public string? CourseCode { get; set; }
        public string? CourseBlockCode { get; set; }
        public string? OccurrenceCode { get; set; }
        public string? ExpectedModeCode { get; set; }
        public string? DecisionResponseCode { get; set; }
        public string? InstitutionTier1 { get; set; }
    }
}
