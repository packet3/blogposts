﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Person
    {
        public string? PersonCode { get; set; }
        public string? Surname { get; set; }
        public string? Forename1 { get; set; }
        public string? Forename2 { get; set; }
        public string? Forename3 { get; set; }
        public string? ForenameUsed { get; set; }
        public string? Initials { get; set; }
        public string? GenderCode { get; set; }
        public string? PersonType { get; set; }
        public string? PreviousSurname { get; set; }
        public string? OfficialName { get; set; }
    }
}
