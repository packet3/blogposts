﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class ZEntityTable
    {
        public string EntityCode { get; set; } = null!;
        public string TableName { get; set; } = null!;
    }
}
