﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Course
    {
        public string InstitutionCode { get; set; } = null!;
        public string CourseCode { get; set; } = null!;
        public string? Title { get; set; }
        public string? EnrolmentStructureTitle { get; set; }
        public string? InstitutionTier2 { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public decimal? CourseLength { get; set; }
        public string? ModeCode { get; set; }
        public string? ExternalSubject1 { get; set; }
        public string? ExternalSubject2 { get; set; }
        public string? ExternalSubject3 { get; set; }
        public string? InstitutionTier1 { get; set; }
        public string? CourseInUse { get; set; }
        public string? PlacementsManagedInPlace { get; set; }
        public string? AllocatePersonalTutors { get; set; }
    }
}
