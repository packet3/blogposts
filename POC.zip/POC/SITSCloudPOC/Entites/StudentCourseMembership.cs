﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class StudentCourseMembership
    {
        public string? StudentProgrammeRouteCode { get; set; }
        public string? StudentCourseJoinCode { get; set; }
        public string? StudentCourseJoinSequenceId { get; set; }
        public string? StudentCode { get; set; }
        public string? AcademicYearCode { get; set; }
        public string? LocationCode { get; set; }
        public string? CourseCode { get; set; }
        public string? CourseBlockCode { get; set; }
        public string? RouteCode { get; set; }
        public string? CourseBlockOccurrenceCode { get; set; }
        public string? ModeCode { get; set; }
        public string? CourseGroupCode { get; set; }
        public DateTime? StartDate { get; set; }
        public string? ReasonforTransferOrWithdrawalCode { get; set; }
        public DateTime? HesaendDate { get; set; }
        public DateTime? ExpectedEndDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? AwardCode { get; set; }
        public string? CourseJoinPersonalTutorId { get; set; }
        public string? CourseJoinPersonalTutorId2 { get; set; }
        public string? StatusCode { get; set; }
        public string? AcademicAssessor { get; set; }
    }
}
