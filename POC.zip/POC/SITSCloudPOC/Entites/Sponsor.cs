﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Sponsor
    {
        public string? StudentCode { get; set; }
        public decimal? SponsorSequenceNumber { get; set; }
        public string? FeeDataGroupCode { get; set; }
        public string? AcademicYearCode { get; set; }
    }
}
