﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class NewValue
    {
        public int Id { get; set; }
        public string ChangeGuid { get; set; } = null!;
        public string Name { get; set; } = null!;
        public string Value { get; set; } = null!;

        public virtual Event ChangeGu { get; set; } = null!;
    }
}
