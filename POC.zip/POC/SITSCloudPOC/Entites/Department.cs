﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Department
    {
        public string Code { get; set; } = null!;
        public string? FullName { get; set; }
        public string? InUse { get; set; }
    }
}
