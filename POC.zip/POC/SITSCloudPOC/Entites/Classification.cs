﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Classification
    {
        public string Code { get; set; } = null!;
        public string? Name { get; set; }
    }
}
