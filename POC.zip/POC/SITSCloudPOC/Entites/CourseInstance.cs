﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class CourseInstance
    {
        public string CourseId { get; set; } = null!;
        public string? AcademicYearCode { get; set; }
        public string? EnrolmentBlockCode { get; set; }
        public string? OccurrenceCode { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
