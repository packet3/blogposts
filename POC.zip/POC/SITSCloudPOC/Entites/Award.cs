﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class Award
    {
        public string Code { get; set; } = null!;
        public string? ExcludeAwardInHedd { get; set; }
        public string? Description { get; set; }
    }
}
