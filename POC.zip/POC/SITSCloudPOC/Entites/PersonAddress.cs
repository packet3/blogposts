﻿using System;
using System.Collections.Generic;

namespace SITSCloudPOC
{
    public partial class PersonAddress
    {
        public string? AddressEntityType { get; set; }
        public string? AddressId { get; set; }
        public string? AddressSequence { get; set; }
        public string? PersonCode { get; set; }
        public string? AddressType { get; set; }
        public string? AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string? AddressLine3 { get; set; }
        public string? AddressLine4 { get; set; }
        public string? AddressLine5 { get; set; }
        public string? AddresPostCode { get; set; }
        public string? AddressMailSort { get; set; }
        public string? AddressActiveFlag { get; set; }
        public string? CountryOfDomicileCode { get; set; }
    }
}
