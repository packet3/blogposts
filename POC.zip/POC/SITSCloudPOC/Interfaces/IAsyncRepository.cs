﻿namespace SITSCloudPOC.Interfaces
{
    public interface IAsyncRepository<T> where T : class
    {
        Task Create(T entity);
        Task<T> UpdateAsync(T entity);
        Task DeleteAsync(T entity);
    }
}
