﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using SITSCloudPOC.Interfaces;

namespace SITSCloudPOC
{
    public partial class DatahubContext : DbContext
    {
        public DatahubContext()
        {
        }

        public DatahubContext(DbContextOptions<DatahubContext> options)
            : base(options)
        {
        }

       
        //public virtual DbSet<AcademicYear> AcademicYears { get; set; } = null!;
        //public virtual DbSet<Applicant> Applicants { get; set; } = null!;
        //public virtual DbSet<Award> Awards { get; set; } = null!;
        //public virtual DbSet<Classification> Classifications { get; set; } = null!;
        //public virtual DbSet<ClearanceCheck> ClearanceChecks { get; set; } = null!;
        //public virtual DbSet<Country> Countries { get; set; } = null!;
        //public virtual DbSet<Course> Courses { get; set; } = null!;
        //public virtual DbSet<CourseApplication> CourseApplications { get; set; } = null!;
        //public virtual DbSet<CourseInstance> CourseInstances { get; set; } = null!;
        //public virtual DbSet<Department> Departments { get; set; } = null!;
        //public virtual DbSet<DisabilityGroup> DisabilityGroups { get; set; } = null!;
        //public virtual DbSet<Faculty> Faculties { get; set; } = null!;
        //public virtual DbSet<FeeStatus> FeeStatuses { get; set; } = null!;
        //public virtual DbSet<Institute> Institutes { get; set; } = null!;
        //public virtual DbSet<Mode> Modes { get; set; } = null!;
        //public virtual DbSet<Module> Modules { get; set; } = null!;
        //public virtual DbSet<Nationality> Nationalities { get; set; } = null!;
        //public virtual DbSet<Person> People { get; set; } = null!;
        //public virtual DbSet<PersonAddress> PersonAddresses { get; set; } = null!;
        //public virtual DbSet<Route> Routes { get; set; } = null!;
        //public virtual DbSet<Sponsor> Sponsors { get; set; } = null!;
        //public virtual DbSet<Status> Statuses { get; set; } = null!;
        //public virtual DbSet<Student> Students { get; set; } = null!;
        //public virtual DbSet<StudentAward> StudentAwards { get; set; } = null!;
        //public virtual DbSet<StudentCertificate> StudentCertificates { get; set; } = null!;
        //public virtual DbSet<StudentClearanceCheck> StudentClearanceChecks { get; set; } = null!;
        //public virtual DbSet<StudentCourseMembership> StudentCourseMemberships { get; set; } = null!;
        //public virtual DbSet<StudentOnCourseInstance> StudentOnCourseInstances { get; set; } = null!;
        //public virtual DbSet<StudentOnModule> StudentOnModules { get; set; } = null!;
        //public virtual DbSet<Title> Titles { get; set; } = null!;
        //public virtual DbSet<ValidCourseOption> ValidCourseOptions { get; set; } = null!;
        //public virtual DbSet<ZEntityTable> ZEntityTables { get; set; } = null!;

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    if (!optionsBuilder.IsConfigured)
        //    {

        //        optionsBuilder.UseSqlServer("Server=DWWEBSTGII04;Database=Datahub;User Id=JoeTest; Password=testingpassword");
        //    }
        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AcademicYear>(entity =>
            {
                entity.HasKey(e => e.AcademicYearCode);

                entity.ToTable("AcademicYear");

                entity.Property(e => e.AcademicYearCode).HasMaxLength(12);

                entity.Property(e => e.AcademicYearStartYear).HasColumnType("numeric(4, 0)");
            });

            modelBuilder.Entity<Applicant>(entity =>
            {
                entity.HasKey(e => e.ApplicantCode);

                entity.ToTable("Applicant");

                entity.Property(e => e.ApplicantCode).HasMaxLength(12);

                entity.Property(e => e.ApplicationFormSequenceNumber).HasMaxLength(2);

                entity.Property(e => e.ApplicationSequenceNumber).HasMaxLength(2);

                entity.Property(e => e.PersonCode).HasMaxLength(12);

                entity.Property(e => e.StudentCourseJoinCode).HasMaxLength(15);
            });

            modelBuilder.Entity<Award>(entity =>
            {
                entity.HasKey(e => e.Code)
                    .HasName("PK_RefAward");

                entity.ToTable("Award");

                entity.Property(e => e.Code).HasMaxLength(12);

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.ExcludeAwardInHedd)
                    .HasMaxLength(15)
                    .HasColumnName("ExcludeAwardInHEDD");
            });

            modelBuilder.Entity<Classification>(entity =>
            {
                entity.HasKey(e => e.Code)
                    .HasName("PK_RefClassification");

                entity.ToTable("Classification");

                entity.Property(e => e.Code).HasMaxLength(6);

                entity.Property(e => e.Name).HasMaxLength(250);
            });

            modelBuilder.Entity<ClearanceCheck>(entity =>
            {
                entity.HasKey(e => e.Code);

                entity.ToTable("ClearanceCheck");

                entity.Property(e => e.Code).HasMaxLength(6);

                entity.Property(e => e.FullName).HasMaxLength(50);
            });

            modelBuilder.Entity<Country>(entity =>
            {
                entity.HasKey(e => e.Code);

                entity.ToTable("Country");

                entity.Property(e => e.Code).HasMaxLength(6);

                entity.Property(e => e.FullName).HasMaxLength(50);

                entity.Property(e => e.GeographicCode).HasMaxLength(6);
            });

            modelBuilder.Entity<Course>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Course");

                entity.Property(e => e.AllocatePersonalTutors).HasMaxLength(15);

                entity.Property(e => e.CourseCode).HasMaxLength(15);

                entity.Property(e => e.CourseInUse).HasMaxLength(1);

                entity.Property(e => e.CourseLength).HasColumnType("numeric(3, 0)");

                entity.Property(e => e.EndDate).HasColumnType("smalldatetime");

                entity.Property(e => e.EnrolmentStructureTitle).HasMaxLength(120);

                entity.Property(e => e.ExternalSubject1).HasMaxLength(6);

                entity.Property(e => e.ExternalSubject2).HasMaxLength(6);

                entity.Property(e => e.ExternalSubject3).HasMaxLength(6);

                entity.Property(e => e.InstitutionCode).HasMaxLength(6);

                entity.Property(e => e.InstitutionTier1).HasMaxLength(6);

                entity.Property(e => e.InstitutionTier2).HasMaxLength(12);

                entity.Property(e => e.ModeCode).HasMaxLength(6);

                entity.Property(e => e.PlacementsManagedInPlace).HasMaxLength(15);

                entity.Property(e => e.StartDate).HasColumnType("smalldatetime");

                entity.Property(e => e.Title).HasMaxLength(50);
            });

            modelBuilder.Entity<CourseApplication>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("CourseApplication");

                entity.Property(e => e.AcademicYearCode).HasMaxLength(12);

                entity.Property(e => e.ApplicantCode).HasMaxLength(12);

                entity.Property(e => e.ApplicationFormSequenceNumber).HasMaxLength(2);

                entity.Property(e => e.ApplicationSequenceNumber).HasMaxLength(2);

                entity.Property(e => e.CourseBlockCode).HasMaxLength(2);

                entity.Property(e => e.CourseCode).HasMaxLength(15);

                entity.Property(e => e.DecisionResponseCode).HasMaxLength(6);

                entity.Property(e => e.ExpectedModeCode).HasMaxLength(6);

                entity.Property(e => e.InstitutionTier1).HasMaxLength(6);

                entity.Property(e => e.OccurrenceCode).HasMaxLength(6);

                entity.Property(e => e.StatusCode).HasMaxLength(6);
            });

            modelBuilder.Entity<CourseInstance>(entity =>
            {
                entity.HasKey(e => e.CourseId);

                entity.ToTable("CourseInstance");

                entity.Property(e => e.CourseId).HasMaxLength(15);

                entity.Property(e => e.AcademicYearCode).HasMaxLength(12);

                entity.Property(e => e.EndDate).HasColumnType("smalldatetime");

                entity.Property(e => e.EnrolmentBlockCode).HasMaxLength(2);

                entity.Property(e => e.OccurrenceCode).HasMaxLength(6);

                entity.Property(e => e.StartDate).HasColumnType("smalldatetime");
            });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.HasKey(e => e.Code)
                    .HasName("PK_RefDepartment");

                entity.ToTable("Department");

                entity.Property(e => e.Code).HasMaxLength(12);

                entity.Property(e => e.FullName).HasMaxLength(250);

                entity.Property(e => e.InUse).HasMaxLength(1);
            });

            modelBuilder.Entity<DisabilityGroup>(entity =>
            {
                entity.HasKey(e => e.Code);

                entity.ToTable("DisabilityGroup");

                entity.Property(e => e.Code).HasMaxLength(3);

                entity.Property(e => e.FullName).HasMaxLength(250);
            });

            modelBuilder.Entity<Faculty>(entity =>
            {
                entity.HasKey(e => e.Code)
                    .HasName("PK_RefFaculty");

                entity.ToTable("Faculty");

                entity.Property(e => e.Code).HasMaxLength(6);

                entity.Property(e => e.FullName).HasMaxLength(100);

                entity.Property(e => e.ShortlName).HasMaxLength(15);
            });

            modelBuilder.Entity<FeeStatus>(entity =>
            {
                entity.HasKey(e => e.Code);

                entity.ToTable("FeeStatus");

                entity.Property(e => e.Code).HasMaxLength(6);

                entity.Property(e => e.FullName).HasMaxLength(15);
            });

            modelBuilder.Entity<Institute>(entity =>
            {
                entity.HasKey(e => e.InstitutionCode)
                    .HasName("PK_RefInstitute");

                entity.ToTable("Institute");

                entity.Property(e => e.InstitutionCode).HasMaxLength(6);

                entity.Property(e => e.InstitutionHesaid)
                    .HasMaxLength(7)
                    .HasColumnName("InstitutionHESAID");

                entity.Property(e => e.TenantName).HasMaxLength(250);
            });

            modelBuilder.Entity<Mode>(entity =>
            {
                entity.HasKey(e => e.Code)
                    .HasName("PK_RefMode");

                entity.ToTable("Mode");

                entity.Property(e => e.Code).HasMaxLength(6);

                entity.Property(e => e.FullName).HasMaxLength(50);
            });

            modelBuilder.Entity<Module>(entity =>
            {
                entity.HasKey(e => e.ModuleCode)
                    .HasName("PK_RefModule");

                entity.ToTable("Module");

                entity.Property(e => e.ModuleCode).HasMaxLength(12);

                entity.Property(e => e.DepartmentCode).HasMaxLength(12);

                entity.Property(e => e.InUse).HasMaxLength(1);

                entity.Property(e => e.ModuleCustomAttribute1).HasMaxLength(15);

                entity.Property(e => e.Name).HasMaxLength(120);

                entity.Property(e => e.ShortName).HasMaxLength(15);
            });

            modelBuilder.Entity<Nationality>(entity =>
            {
                entity.HasKey(e => e.Code);

                entity.ToTable("Nationality");

                entity.Property(e => e.Code).HasMaxLength(6);

                entity.Property(e => e.FullName).HasMaxLength(250);
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Person");

                entity.Property(e => e.Forename1).HasMaxLength(30);

                entity.Property(e => e.Forename2).HasMaxLength(30);

                entity.Property(e => e.Forename3).HasMaxLength(30);

                entity.Property(e => e.ForenameUsed).HasMaxLength(30);

                entity.Property(e => e.GenderCode).HasMaxLength(1);

                entity.Property(e => e.Initials).HasMaxLength(3);

                entity.Property(e => e.OfficialName).HasMaxLength(150);

                entity.Property(e => e.PersonCode).HasMaxLength(12);

                entity.Property(e => e.PersonType).HasMaxLength(1);

                entity.Property(e => e.PreviousSurname).HasMaxLength(40);

                entity.Property(e => e.Surname).HasMaxLength(40);
            });

            modelBuilder.Entity<PersonAddress>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("PersonAddress");

                entity.Property(e => e.AddresPostCode).HasMaxLength(12);

                entity.Property(e => e.AddressActiveFlag).HasMaxLength(1);

                entity.Property(e => e.AddressEntityType).HasMaxLength(6);

                entity.Property(e => e.AddressId)
                    .HasMaxLength(20)
                    .HasColumnName("AddressID");

                entity.Property(e => e.AddressLine1).HasMaxLength(50);

                entity.Property(e => e.AddressLine2).HasMaxLength(50);

                entity.Property(e => e.AddressLine3).HasMaxLength(50);

                entity.Property(e => e.AddressLine4).HasMaxLength(50);

                entity.Property(e => e.AddressLine5).HasMaxLength(50);

                entity.Property(e => e.AddressMailSort).HasMaxLength(5);

                entity.Property(e => e.AddressSequence).HasMaxLength(4);

                entity.Property(e => e.AddressType).HasMaxLength(6);

                entity.Property(e => e.CountryOfDomicileCode).HasMaxLength(6);

                entity.Property(e => e.PersonCode).HasMaxLength(12);
            });

            modelBuilder.Entity<Route>(entity =>
            {
                entity.HasKey(e => e.Code)
                    .HasName("PK_RefRoute");

                entity.ToTable("Route");

                entity.Property(e => e.Code).HasMaxLength(12);

                entity.Property(e => e.DisciplineInPlacements).HasMaxLength(100);
            });

            modelBuilder.Entity<Sponsor>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Sponsor");

                entity.Property(e => e.AcademicYearCode).HasMaxLength(12);

                entity.Property(e => e.FeeDataGroupCode).HasMaxLength(6);

                entity.Property(e => e.SponsorSequenceNumber).HasColumnType("numeric(6, 0)");

                entity.Property(e => e.StudentCode).HasMaxLength(12);
            });

            modelBuilder.Entity<Status>(entity =>
            {
                entity.HasKey(e => e.Code)
                    .HasName("PK_RefStatus");

                entity.ToTable("Status");

                entity.Property(e => e.Code).HasMaxLength(6);

                entity.Property(e => e.FullName).HasMaxLength(50);
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Student");

                entity.Property(e => e.ActivityAnalysis2).HasMaxLength(6);

                entity.Property(e => e.InstitutionCode).HasMaxLength(6);

                entity.Property(e => e.Overseas).HasMaxLength(1);

                entity.Property(e => e.PersonCode).HasMaxLength(12);

                entity.Property(e => e.PublicityFlag).HasMaxLength(1);

                entity.Property(e => e.SponsorCode).HasMaxLength(12);

                entity.Property(e => e.StudentCode).HasMaxLength(12);

                entity.Property(e => e.StudentStatusCode).HasMaxLength(6);

                entity.Property(e => e.StudentSupportNumber).HasMaxLength(13);

                entity.Property(e => e.Tier4Visa).HasMaxLength(15);

                entity.Property(e => e.Ucasid)
                    .HasMaxLength(10)
                    .HasColumnName("UCASID");

                entity.Property(e => e.Ukvi)
                    .HasMaxLength(1)
                    .HasColumnName("UKVI");
            });

            modelBuilder.Entity<StudentAward>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("StudentAward");

                entity.Property(e => e.AcademicYearCode).HasMaxLength(12);

                entity.Property(e => e.AwardCode).HasMaxLength(12);

                entity.Property(e => e.AwardStatusCode).HasMaxLength(6);

                entity.Property(e => e.DateAwardConferred).HasColumnType("smalldatetime");

                entity.Property(e => e.FullName).HasMaxLength(2000);

                entity.Property(e => e.HeddprocessedDate)
                    .HasMaxLength(15)
                    .HasColumnName("HEDDProcessedDate");

                entity.Property(e => e.Heddstatus)
                    .HasMaxLength(15)
                    .HasColumnName("HEDDStatus");

                entity.Property(e => e.StudentCourseMembershipId)
                    .HasMaxLength(15)
                    .HasColumnName("StudentCourseMembershipID");
            });

            modelBuilder.Entity<StudentCertificate>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("StudentCertificate");

                entity.Property(e => e.AwardCode).HasMaxLength(12);

                entity.Property(e => e.AwardDate).HasColumnType("smalldatetime");

                entity.Property(e => e.ClassificationCode).HasMaxLength(6);

                entity.Property(e => e.SequenceNumber).HasColumnType("numeric(5, 0)");

                entity.Property(e => e.StudentCourseMembershipId)
                    .HasMaxLength(15)
                    .HasColumnName("StudentCourseMembershipID");
            });

            modelBuilder.Entity<StudentClearanceCheck>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("StudentClearanceCheck");

                entity.Property(e => e.ApplicationFormSequenceNumber).HasColumnType("numeric(3, 0)");

                entity.Property(e => e.ApplicationSequenceNumber).HasColumnType("numeric(3, 0)");

                entity.Property(e => e.ClearanceCheckCode).HasMaxLength(6);

                entity.Property(e => e.ClearanceChecked).HasMaxLength(1);

                entity.Property(e => e.SequenceNumber).HasMaxLength(4);

                entity.Property(e => e.StudentCode).HasMaxLength(12);
            });

            modelBuilder.Entity<StudentCourseMembership>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("StudentCourseMembership");

                entity.Property(e => e.AcademicAssessor).HasMaxLength(15);

                entity.Property(e => e.AcademicYearCode).HasMaxLength(12);

                entity.Property(e => e.AwardCode).HasMaxLength(12);

                entity.Property(e => e.CourseBlockCode).HasMaxLength(2);

                entity.Property(e => e.CourseBlockOccurrenceCode).HasMaxLength(6);

                entity.Property(e => e.CourseCode).HasMaxLength(15);

                entity.Property(e => e.CourseGroupCode).HasMaxLength(12);

                entity.Property(e => e.CourseJoinPersonalTutorId).HasMaxLength(12);

                entity.Property(e => e.CourseJoinPersonalTutorId2).HasMaxLength(12);

                entity.Property(e => e.EndDate).HasColumnType("smalldatetime");

                entity.Property(e => e.ExpectedEndDate).HasColumnType("smalldatetime");

                entity.Property(e => e.HesaendDate)
                    .HasColumnType("smalldatetime")
                    .HasColumnName("HESAEndDate");

                entity.Property(e => e.LocationCode).HasMaxLength(12);

                entity.Property(e => e.ModeCode).HasMaxLength(6);

                entity.Property(e => e.ReasonforTransferOrWithdrawalCode).HasMaxLength(6);

                entity.Property(e => e.RouteCode).HasMaxLength(12);

                entity.Property(e => e.StartDate).HasColumnType("smalldatetime");

                entity.Property(e => e.StatusCode).HasMaxLength(6);

                entity.Property(e => e.StudentCode).HasMaxLength(12);

                entity.Property(e => e.StudentCourseJoinCode).HasMaxLength(15);

                entity.Property(e => e.StudentCourseJoinSequenceId).HasMaxLength(2);

                entity.Property(e => e.StudentProgrammeRouteCode).HasMaxLength(15);
            });

            modelBuilder.Entity<StudentOnCourseInstance>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("StudentOnCourseInstance");

                entity.Property(e => e.AcademicYearCode).HasMaxLength(12);

                entity.Property(e => e.CourseBlockCode).HasMaxLength(2);

                entity.Property(e => e.CourseBlockOccurrenceCode).HasMaxLength(6);

                entity.Property(e => e.CourseCode).HasMaxLength(15);

                entity.Property(e => e.CourseGroupCode).HasMaxLength(12);

                entity.Property(e => e.DepartmentCode).HasMaxLength(12);

                entity.Property(e => e.EndDate).HasColumnType("smalldatetime");

                entity.Property(e => e.EnrolmentStatusCode).HasMaxLength(6);

                entity.Property(e => e.FacultyCode).HasMaxLength(6);

                entity.Property(e => e.FeeStatusCode).HasMaxLength(6);

                entity.Property(e => e.ModeCode).HasMaxLength(6);

                entity.Property(e => e.NextCourseBlockCode).HasMaxLength(2);

                entity.Property(e => e.NextCourseCode).HasMaxLength(15);

                entity.Property(e => e.NextCourseOccurrenceCode).HasMaxLength(6);

                entity.Property(e => e.NextRouteCode).HasMaxLength(12);

                entity.Property(e => e.NextStatusCode).HasMaxLength(6);

                entity.Property(e => e.ProgresStatus).HasMaxLength(3);

                entity.Property(e => e.RouteCode).HasMaxLength(12);

                entity.Property(e => e.SequenceNumber).HasMaxLength(2);

                entity.Property(e => e.StartDate).HasColumnType("smalldatetime");

                entity.Property(e => e.StudentCode).HasMaxLength(12);

                entity.Property(e => e.StudentCourseJoinCode).HasMaxLength(15);
            });

            modelBuilder.Entity<StudentOnModule>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("StudentOnModule");

                entity.Property(e => e.AcademicYearCode).HasMaxLength(12);

                entity.Property(e => e.Keatsaccess)
                    .HasMaxLength(15)
                    .HasColumnName("KEATSAccess");

                entity.Property(e => e.ModuleCode).HasMaxLength(12);

                entity.Property(e => e.Occurrence).HasMaxLength(6);

                entity.Property(e => e.PeriodSlotCode).HasMaxLength(6);

                entity.Property(e => e.StudentCourseMembershipId)
                    .HasMaxLength(15)
                    .HasColumnName("StudentCourseMembershipID");
            });

            modelBuilder.Entity<Title>(entity =>
            {
                entity.HasKey(e => e.Code);

                entity.ToTable("Title");

                entity.Property(e => e.Code).HasMaxLength(12);

                entity.Property(e => e.FullName).HasMaxLength(50);
            });

            modelBuilder.Entity<ValidCourseOption>(entity =>
            {
                entity.HasKey(e => e.CourseCode)
                    .HasName("PK_RefValidCourseOption");

                entity.ToTable("ValidCourseOption");

                entity.Property(e => e.CourseCode).HasMaxLength(15);

                entity.Property(e => e.InPlaceCourseDescription).HasMaxLength(100);

                entity.Property(e => e.InUse).HasMaxLength(1);

                entity.Property(e => e.SequenceNumber).HasColumnType("numeric(6, 0)");
            });

            modelBuilder.Entity<ZEntityTable>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("zEntityTable");

                entity.Property(e => e.EntityCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TableName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

      
    }
}
