﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SITSCloudPOC.Features.Event;


namespace SITSCloudPOC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProcessEventController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ProcessEventController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        public async Task<ActionResult> Process([FromBody] CreateEventCommand createEventCommand)
        {
            //Take Json Message and store it at CreateEventCommand
            var response = await _mediator.Send(createEventCommand);
            return Ok(response);
        }
    }
}
